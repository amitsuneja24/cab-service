package com.thinkify.cabs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabServiceApplication {
	
	public static void main(String[] args) {		
		SpringApplication.run(CabServiceApplication.class, args);
	}

}
