package com.thinkify.cabs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
